# Question 1(i)
- First, using "open" command, I copied all the data into list 'l'.
- Then, copied the list 'l' into "list1" except the last 6 columns.

# Question 1(ii)
- created a lambda function to check the given condition.
- Then, using filter and that lambda function I eliminated the rows which satisfies the condition.

# Question 1(iii)
- created three list one for each Open,high and low append the data in to it.
-  then take the average and store into a txt file.

# Question 1(iv)
- it takes input and based on that char it filter the rows containing the names start with that char.

# Question 1(v)
- Store the result of question 1(iv) into txt as asked.